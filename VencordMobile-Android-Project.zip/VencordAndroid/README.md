# Vencord Mobile (Android 8 – Android 16)

A native Android app (WebView) that opens Discord and injects the official Vencord web build
(`app/src/main/assets/Vencord.user.js`) at document start. Vencord settings appear inside
Discord's User Settings, as on desktop.

## Mobile settings screen
A round **V** button floats over Discord. Tap it for a full-screen, touch-friendly panel:
- **Plugins:** search, filter, switch plugins on/off (same logic as Vencord's own plugin tab,
  including dependencies and "needs reload"), and jump to a plugin's own options via the gear.
- **Phone:** Discord UI scale, bigger touch targets, reduce animations, button side/opacity.
- **Backup:** export/import all Vencord settings, reload Discord.

## Build the APK (pick one)

**A. Android Studio (easiest):** File > Open this folder, wait for Gradle sync,
Build > Build APK(s). The APK is in `app/build/outputs/apk/debug/app-debug.apk`.

**B. Command line (needs JDK 17 + Android SDK):** `./gradlew assembleDebug`

**C. No PC:** push this folder to a GitHub repo, open Actions > "Build APK" > Run workflow,
download the `VencordMobile-debug-apk` artifact, unzip, copy the APK to your phone.

## Install
Copy the APK to the phone, open it, allow "install unknown apps" for your file manager/browser,
install, open "Vencord", log in.

## Updating Vencord
Replace `app/src/main/assets/Vencord.user.js` with the latest from
https://github.com/Vendicated/Vencord/releases/download/devbuild/Vencord.user.js and rebuild.

## Limits
- It's Discord's web client in a WebView, not the official Discord app (no push notifications,
  voice stops when the app is in the background).
- Desktop-only Vencord native plugins won't work.
- Client mods are against Discord's Terms of Service.
