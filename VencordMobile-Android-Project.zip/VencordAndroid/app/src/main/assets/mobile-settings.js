// Vencord Mobile settings: touch-friendly plugin manager + phone options.
// Runs after Vencord.user.js; waits until window.Vencord is ready.
(function () {
  if (window.__vcMobileUI) return; window.__vcMobileUI = true;

  const LS = "VencordMobileSettings";
  const defaults = { scale: 100, bigTargets: true, reduceMotion: false, btnSide: "right", btnOpacity: 85 };
  const load = () => { try { return Object.assign({}, defaults, JSON.parse(localStorage.getItem(LS) || "{}")); } catch (_) { return { ...defaults }; } };
  const save = () => { try { localStorage.setItem(LS, JSON.stringify(opts)); } catch (_) {} };
  let opts = load();

  // ---------- page-level phone tweaks (applied to Discord itself) ----------
  const tweakStyle = document.createElement("style");
  tweakStyle.id = "vc-mobile-tweaks";
  function applyTweaks() {
    let css = "";
    if (opts.scale !== 100) css += `html{zoom:${opts.scale / 100}}`;
    if (opts.bigTargets) css += `
      [role="menuitem"],[role="option"],[class*="menuItem"]{min-height:44px}
      [class*="tabBar"] [role="tab"],[class*="sidebar"] [role="tab"]{min-height:44px}
      [class*="iconWrapper"],[class*="actionButtons"] button{min-width:36px;min-height:36px}`;
    if (opts.reduceMotion) css += `*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}`;
    tweakStyle.textContent = css;
    host.style.zoom = opts.scale !== 100 ? String(100 / opts.scale) : ""; // keep this panel at normal size
    if (!tweakStyle.isConnected) (document.head || document.documentElement).appendChild(tweakStyle);
  }

  // ---------- helpers ----------
  const V = () => window.Vencord;
  const pluginList = () => {
    const P = V().Plugins; const S = V().Settings;
    return Object.values(P.plugins)
      .filter(p => !p.hidden && !String(p.name).startsWith("_"))
      .map(p => ({
        p, name: p.name, desc: p.description || "",
        enabled: !!P.isPluginEnabled(p.name),
        locked: !!(p.required || p.isDependency),
        restart: !!P.pluginRequiresRestart(p),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  };

  let needsReload = false;
  function toggle(item) {
    const { Plugins: PM, Settings: S } = V();
    const plugin = item.p; const settings = S.plugins[plugin.name];
    const was = PM.isPluginEnabled(plugin.name);
    if (!was) {
      const { restartNeeded, failures } = PM.startDependenciesRecursive(plugin);
      if (failures.length) return toast("Failed to start dependencies: " + failures.join(", "));
      if (restartNeeded) { settings.enabled = true; needsReload = true; return; }
    }
    if (PM.pluginRequiresRestart(plugin)) { settings.enabled = !was; needsReload = true; return; }
    if (was && !plugin.started) { settings.enabled = false; return; }
    const ok = was ? PM.stopPlugin(plugin) : PM.startPlugin(plugin);
    if (!ok) { settings.enabled = false; return toast(`Error ${was ? "stopping" : "starting"} ${plugin.name}`); }
    settings.enabled = !was;
  }

  // ---------- UI (inside a shadow root so Discord's CSS can't touch it) ----------
  const host = document.createElement("div");
  host.id = "vc-mobile-host";
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
  <style>
    :host{all:initial}
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Roboto,sans-serif}
    .fab{position:fixed;bottom:84px;width:48px;height:48px;border-radius:50%;border:0;background:#5865f2;color:#fff;
      font-size:22px;font-weight:700;box-shadow:0 2px 10px #0008;z-index:2147483646;touch-action:manipulation}
    .sheet{position:fixed;inset:0;background:#1e1f22;color:#f2f3f5;z-index:2147483647;display:none;flex-direction:column}
    .sheet.open{display:flex}
    header{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#2b2d31;border-bottom:1px solid #0004}
    header h1{font-size:18px;margin:0;flex:1}
    button{font:inherit;color:inherit}
    .x{background:#3a3c43;border:0;border-radius:8px;min-width:44px;min-height:44px;font-size:18px}
    nav{display:flex;background:#2b2d31}
    nav button{flex:1;min-height:48px;background:none;border:0;border-bottom:3px solid transparent;color:#b5bac1;font-size:15px}
    nav button.on{color:#fff;border-color:#5865f2}
    main{flex:1;overflow:auto;padding:12px;-webkit-overflow-scrolling:touch}
    .banner{background:#5865f2;border-radius:10px;padding:10px 12px;margin-bottom:12px;display:flex;gap:10px;align-items:center}
    .banner span{flex:1;font-size:14px}
    .btn{background:#4752c4;border:0;border-radius:8px;min-height:44px;padding:0 14px;font-size:15px}
    .btn.alt{background:#3a3c43}
    input[type=search],textarea{width:100%;min-height:44px;border-radius:8px;border:1px solid #0006;background:#111214;color:#f2f3f5;padding:8px 12px;font-size:16px}
    .chips{display:flex;gap:8px;margin:10px 0;overflow-x:auto}
    .chip{white-space:nowrap;min-height:40px;padding:0 14px;border-radius:20px;border:0;background:#2b2d31;color:#b5bac1}
    .chip.on{background:#5865f2;color:#fff}
    .row{display:flex;align-items:center;gap:12px;background:#2b2d31;border-radius:10px;padding:12px;margin-bottom:8px}
    .row .t{flex:1;min-width:0}
    .row .n{font-weight:600;font-size:15px}
    .row .d{font-size:13px;color:#b5bac1;margin-top:2px;overflow-wrap:anywhere}
    .tag{font-size:11px;background:#3a3c43;border-radius:6px;padding:1px 6px;margin-left:6px;color:#b5bac1}
    .gear{background:#3a3c43;border:0;border-radius:8px;min-width:44px;min-height:44px}
    .sw{position:relative;width:52px;height:30px;flex:none;border-radius:15px;background:#4e5058;border:0;padding:0}
    .sw::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;transition:left .15s}
    .sw.on{background:#23a559}.sw.on::after{left:25px}
    .sw:disabled{opacity:.5}
    .opt{background:#2b2d31;border-radius:10px;padding:12px;margin-bottom:10px}
    .opt label{display:flex;justify-content:space-between;align-items:center;gap:12px;min-height:44px;font-size:15px}
    .opt small{display:block;color:#b5bac1;font-size:12px;margin-top:2px}
    input[type=range]{width:100%;height:44px}
    .seg{display:flex;gap:8px}
    .seg button{flex:1;min-height:44px;border:0;border-radius:8px;background:#3a3c43}
    .seg button.on{background:#5865f2}
    .toast{position:fixed;left:12px;right:12px;bottom:24px;background:#111214;border-radius:10px;padding:12px;z-index:2147483647;display:none;font-size:14px}
    p.note{color:#b5bac1;font-size:13px;line-height:1.5}
  </style>
  <button class="fab" id="fab" aria-label="Vencord Mobile settings">V</button>
  <div class="sheet" id="sheet" role="dialog" aria-modal="true">
    <header><h1>Vencord Mobile</h1><button class="x" id="close" aria-label="Close">✕</button></header>
    <nav><button data-tab="plugins" class="on">Plugins</button><button data-tab="phone">Phone</button><button data-tab="backup">Backup</button></nav>
    <main id="main"></main>
  </div>
  <div class="toast" id="toast"></div>`;
  const $ = (s) => root.querySelector(s);
  let toastTimer;
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.style.display = "block"; clearTimeout(toastTimer); toastTimer = setTimeout(() => t.style.display = "none", 3500); }

  let tab = "plugins", query = "", filter = "all";
  const el = (tag, props = {}, ...kids) => { const e = document.createElement(tag); for (const k in props) { if (k === "class") e.className = props[k]; else if (k.startsWith("on")) e.addEventListener(k.slice(2), props[k]); else e[k] = props[k]; } kids.flat().filter(c => c != null && c !== false).forEach(c => e.append(c)); return e; };

  function renderPlugins() {
    const main = $("#main"); main.textContent = "";
    if (needsReload) main.append(el("div", { class: "banner" }, el("span", {}, "Some changes need a reload to take effect."), el("button", { class: "btn", onclick: () => location.reload() }, "Reload")));
    const search = el("input", { type: "search", placeholder: "Search plugins…", value: query });
    const listBox = el("div");
    search.addEventListener("input", () => { query = search.value.toLowerCase(); renderList(); });
    const chips = el("div", { class: "chips" }, [["all", "All"], ["on", "Enabled"], ["off", "Disabled"]].map(([k, label]) =>
      el("button", { class: "chip" + (filter === k ? " on" : ""), onclick: () => { filter = k; renderPlugins(); } }, label)));
    main.append(search, chips, listBox);
    function renderList() {
      listBox.textContent = "";
      let items = pluginList().filter(i => (filter === "all" || (filter === "on") === i.enabled) && (i.name + " " + i.desc).toLowerCase().includes(query));
      if (!items.length) listBox.append(el("p", { class: "note" }, "No plugins match."));
      items.slice(0, 300).forEach(i => {
        const sw = el("button", { class: "sw" + (i.enabled ? " on" : ""), disabled: i.locked, role: "switch", "aria-checked": String(i.enabled), "aria-label": i.name });
        sw.addEventListener("click", () => { toggle(i); renderPlugins(); });
        const hasSettings = !!(i.p.settings && Object.keys(i.p.settings.def || {}).length) || !!i.p.settingsAboutComponent;
        const gear = hasSettings ? el("button", { class: "gear", "aria-label": "Settings for " + i.name, onclick: () => openVencordPluginSettings() }, "⚙") : null;
        listBox.append(el("div", { class: "row" },
          el("div", { class: "t" }, el("div", { class: "n" }, i.name, i.restart ? el("span", { class: "tag" }, "needs reload") : "", i.locked ? el("span", { class: "tag" }, "required") : ""), el("div", { class: "d" }, i.desc)),
          gear, sw));
      });
    }
    renderList();
  }

  function openVencordPluginSettings() {
    try { closeSheet(); V().Webpack.Common.SettingsRouter.openUserSettings("vencord_plugins_panel"); }
    catch (e) { toast("Open Discord User Settings > Vencord > Plugins for this plugin's options."); }
  }

  function renderPhone() {
    const main = $("#main"); main.textContent = "";
    const opt = (...k) => el("div", { class: "opt" }, ...k);
    const scaleVal = el("span", {}, opts.scale + "%");
    const scale = el("input", { type: "range", min: 60, max: 140, step: 5, value: opts.scale });
    scale.addEventListener("input", () => scaleVal.textContent = scale.value + "%");
    scale.addEventListener("change", () => { opts.scale = +scale.value; save(); applyTweaks(); });
    const check = (key, label, hint) => {
      const cb = el("input", { type: "checkbox", checked: !!opts[key] }); cb.style.cssText = "width:24px;height:24px";
      cb.addEventListener("change", () => { opts[key] = cb.checked; save(); applyTweaks(); });
      return opt(el("label", {}, el("span", {}, label, el("small", {}, hint)), cb));
    };
    const side = el("div", { class: "seg" }, ["left", "right"].map(s => el("button", { class: opts.btnSide === s ? "on" : "", onclick: () => { opts.btnSide = s; save(); placeFab(); renderPhone(); } }, s === "left" ? "Left" : "Right")));
    const op = el("input", { type: "range", min: 30, max: 100, step: 5, value: opts.btnOpacity });
    op.addEventListener("change", () => { opts.btnOpacity = +op.value; save(); placeFab(); });
    main.append(
      opt(el("label", {}, el("span", {}, "Discord UI scale"), scaleVal), scale, el("small", { style: "color:#b5bac1" }, "Make everything bigger or smaller. Reload if layout looks off.")),
      check("bigTargets", "Bigger touch targets", "Taller menu items and buttons"),
      check("reduceMotion", "Reduce animations", "Smoother on slower phones"),
      opt(el("div", { style: "margin-bottom:8px" }, "Settings button side"), side),
      opt(el("div", {}, "Settings button opacity"), op),
      el("button", { class: "btn alt", style: "width:100%", onclick: () => { opts = { ...defaults }; save(); applyTweaks(); placeFab(); renderPhone(); } }, "Reset phone options"));
  }

  function renderBackup() {
    const main = $("#main"); main.textContent = "";
    const ta = el("textarea", { rows: 8, placeholder: "Paste settings JSON here to import" });
    main.append(
      el("p", { class: "note" }, "Export copies all Vencord settings (plugins and their options) so you can keep or move them. Import replaces your current settings and reloads."),
      el("button", { class: "btn", style: "width:100%;margin-bottom:10px", onclick: async () => {
        const json = localStorage.getItem("VencordSettings") || "{}";
        try { await navigator.clipboard.writeText(json); toast("Settings copied to clipboard"); } catch (_) { ta.value = json; ta.select(); toast("Copy the text below manually"); }
      } }, "Export to clipboard"),
      ta,
      el("button", { class: "btn alt", style: "width:100%;margin-top:10px", onclick: () => {
        try { const o = JSON.parse(ta.value); if (typeof o !== "object" || !o) throw 0; localStorage.setItem("VencordSettings", JSON.stringify(o)); location.reload(); }
        catch (_) { toast("That isn't valid settings JSON."); }
      } }, "Import and reload"),
      el("button", { class: "btn alt", style: "width:100%;margin-top:10px", onclick: () => location.reload() }, "Reload Discord"));
  }

  function render() {
    root.querySelectorAll("nav button").forEach(b => b.classList.toggle("on", b.dataset.tab === tab));
    ({ plugins: renderPlugins, phone: renderPhone, backup: renderBackup })[tab]();
  }
  function openSheet() { $("#sheet").classList.add("open"); render(); }
  function closeSheet() { $("#sheet").classList.remove("open"); }
  function placeFab() {
    const f = $("#fab"); f.style.left = opts.btnSide === "left" ? "12px" : "auto"; f.style.right = opts.btnSide === "right" ? "12px" : "auto"; f.style.opacity = opts.btnOpacity / 100;
  }
  $("#fab").addEventListener("click", openSheet);
  $("#close").addEventListener("click", closeSheet);
  root.querySelectorAll("nav button").forEach(b => b.addEventListener("click", () => { tab = b.dataset.tab; render(); }));
  placeFab(); applyTweaks();

  // ---------- wait for Vencord + DOM, then mount ----------
  const t0 = Date.now();
  const timer = setInterval(() => {
    const ready = window.Vencord && V().Plugins && V().Plugins.plugins && V().Settings && document.body;
    if (ready) { clearInterval(timer); document.documentElement.appendChild(host); applyTweaks(); }
    else if (Date.now() - t0 > 60000) clearInterval(timer);
  }, 400);
})();
