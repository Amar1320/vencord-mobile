// Provides the Tampermonkey APIs that Vencord.user.js expects (unsafeWindow, GM_xmlhttpRequest).
(function () {
  if (window.__vcShim || typeof AndroidGM === "undefined") return;
  window.__vcShim = true;
  window.unsafeWindow = window;
  const pending = new Map();
  let nextId = 1;

  AndroidGM.onmessage = (ev) => {
    let m; try { m = JSON.parse(ev.data); } catch (_) { return; }
    const p = pending.get(m.id); if (!p) return;
    pending.delete(m.id);
    const d = p.details;
    if (m.error) { d.onerror && d.onerror({ error: m.error, status: 0 }); return; }
    let response = null;
    if (m.body != null) {
      const bin = atob(m.body), u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const rt = d.responseType;
      if (rt === "arraybuffer") response = u8.buffer;
      else if (rt === "blob") response = new Blob([u8], { type: m.contentType || "" });
      else response = new TextDecoder("utf-8").decode(u8);
    }
    const res = {
      status: m.status, statusText: m.statusText || "", finalUrl: m.finalUrl,
      responseHeaders: m.headers || "", response,
      responseText: typeof response === "string" ? response : "", readyState: 4,
    };
    d.onload && d.onload(res);
    d.onloadend && d.onloadend(res);
  };

  window.GM_xmlhttpRequest = function (details) {
    const id = nextId++;
    pending.set(id, { details });
    let data = details.data;
    if (data != null && typeof data !== "string") data = String(data);
    AndroidGM.postMessage(JSON.stringify({
      id, url: String(details.url), method: details.method || "GET",
      headers: details.headers || {}, data: data == null ? null : data,
      timeout: details.timeout || 0,
    }));
    return { abort() { pending.delete(id); details.onabort && details.onabort({}); } };
  };
})();
