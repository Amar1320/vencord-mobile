package dev.vencordmobile;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Full-screen WebView running Discord's web app with Vencord injected at document start. */
public class MainActivity extends Activity {
    private static final String START_URL = "https://discord.com/app";
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/140.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 1, REQ_PERM = 2;
    private static final int MAX_BODY = 64 * 1024 * 1024;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPermission;
    private final ExecutorService io = Executors.newCachedThreadPool();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        // Android 15/16 force edge-to-edge: keep content clear of bars and the keyboard.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.ime()
                                | WindowInsets.Type.displayCutout());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return WindowInsets.CONSUMED;
        });

        setupWebView();

        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedCallback cb = this::handleBack;
            getOnBackInvokedDispatcher()
                    .registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
        }

        if (savedInstanceState == null) web.loadUrl(START_URL);
    }

    private void handleBack() {
        if (web.canGoBack()) web.goBack(); else moveTaskToBack(true);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { // used below Android 13
        handleBack();
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(DESKTOP_UA); // mobile UA makes discord.com redirect to the "get the app" page
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        boolean ok = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)
                && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (ok) {
            // Only Discord origins get the bridge and the script.
            Set<String> origins = new HashSet<>(Arrays.asList(
                    "https://discord.com", "https://*.discord.com"));
            WebViewCompat.addWebMessageListener(web, "AndroidGM", origins,
                    (view, message, sourceOrigin, isMainFrame, reply) ->
                            handleGmMessage(message, reply));
            String script = readAsset("shim.js") + "\n" + readAsset("Vencord.user.js")
                    + "\n" + readAsset("mobile-settings.js");
            WebViewCompat.addDocumentStartJavaScript(web, script, origins);
        } else {
            Toast.makeText(this,
                    "Please update Android System WebView / Chrome, then reopen the app.",
                    Toast.LENGTH_LONG).show();
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme(), host = u.getHost();
                if (("https".equals(scheme) || "http".equals(scheme)) && host != null
                        && (isHost(host, "discord.com") || isHost(host, "discordapp.com")
                        || isHost(host, "discord.gg") || isHost(host, "hcaptcha.com"))) {
                    return false;
                }
                if ("about".equals(scheme)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handlePermission(request));
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            if (!url.startsWith("http")) return;
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                String name = URLUtil.guessFileName(url, cd, mime);
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) r.addRequestHeader("Cookie", cookie);
                r.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Downloading " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static boolean isHost(String host, String domain) {
        return host.equals(domain) || host.endsWith("." + domain);
    }

    // ---- mic / camera for voice & video ----
    private void handlePermission(PermissionRequest request) {
        List<String> need = new ArrayList<>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) need.add(Manifest.permission.RECORD_AUDIO);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) need.add(Manifest.permission.CAMERA);
        }
        List<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingPermission != null) pendingPermission.deny();
            pendingPermission = request;
            requestPermissions(missing.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERM || pendingPermission == null) return;
        boolean all = results.length > 0;
        for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) all = false;
        if (all) pendingPermission.grant(pendingPermission.getResources());
        else pendingPermission.deny();
        pendingPermission = null;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || fileCallback == null) return;
        fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
        fileCallback = null;
    }

    // ---- GM_xmlhttpRequest bridge (CORS-free requests used by Vencord for themes etc.) ----
    private void handleGmMessage(WebMessageCompat message, JavaScriptReplyProxy reply) {
        String data = message.getData();
        if (data == null) return;
        io.execute(() -> {
            int id = -1;
            String out;
            try {
                JSONObject req = new JSONObject(data);
                id = req.getInt("id");
                out = doRequest(id, req);
            } catch (Throwable t) {
                out = errorJson(id, String.valueOf(t));
            }
            final String msg = out;
            runOnUiThread(() -> reply.postMessage(msg));
        });
    }

    private static String errorJson(int id, String err) {
        try {
            return new JSONObject().put("id", id).put("error", err).toString();
        } catch (Exception e) {
            return "{\"id\":" + id + ",\"error\":\"error\"}";
        }
    }

    private static String doRequest(int id, JSONObject req) throws Exception {
        URL url = new URL(req.getString("url"));
        String proto = url.getProtocol();
        if (!"https".equals(proto) && !"http".equals(proto)) throw new Exception("blocked scheme");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        int timeout = req.optInt("timeout", 0);
        c.setConnectTimeout(timeout > 0 ? timeout : 30000);
        c.setReadTimeout(timeout > 0 ? timeout : 30000);
        c.setInstanceFollowRedirects(true);
        String method = req.optString("method", "GET").toUpperCase();
        c.setRequestMethod(method);
        JSONObject headers = req.optJSONObject("headers");
        if (headers != null) {
            for (Iterator<String> it = headers.keys(); it.hasNext(); ) {
                String k = it.next();
                c.setRequestProperty(k, headers.optString(k));
            }
        }
        if (!req.isNull("data") && !method.equals("GET") && !method.equals("HEAD")) {
            byte[] body = req.getString("data").getBytes("UTF-8");
            c.setDoOutput(true);
            try (OutputStream os = c.getOutputStream()) { os.write(body); }
        }
        int status = c.getResponseCode();
        InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        if (in != null) {
            byte[] buf = new byte[16384];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BODY) throw new Exception("response too large");
                bos.write(buf, 0, n);
            }
            in.close();
        }
        StringBuilder hs = new StringBuilder();
        for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
            if (e.getKey() == null) continue;
            for (String v : e.getValue()) hs.append(e.getKey()).append(": ").append(v).append("\r\n");
        }
        JSONObject out = new JSONObject();
        out.put("id", id);
        out.put("status", status);
        out.put("statusText", c.getResponseMessage());
        out.put("headers", hs.toString());
        out.put("finalUrl", c.getURL().toString());
        out.put("contentType", c.getContentType());
        out.put("body", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP));
        c.disconnect();
        return out.toString();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        web.destroy();
        super.onDestroy();
    }
}
